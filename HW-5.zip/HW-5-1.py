''' Задание №1
'''

file = open("HW-5-1.txt", "w")
line = input("Введите текст:\n")
while line:
    file.writelines("{}\n".format(line))
    line = input("Введите текст:\n")
    if not line:
        break
file.close()

with open("HW-5-1.txt", "r") as file:
    print(file.readlines())
file.close()
