''' Задание №2
'''

with open("HW-5-2.txt", "r") as file:
    word_count = 0
    content = file.readlines()
    print("Содержимое файла: \n{}".format(content))
    print("Количество строк в файле: {}".format(len(content)))
    for index, value in enumerate(content):
        print("Строка: {0} количество слов: {1}".format(
            (index + 1), len(value.split())))
        word_count += len(value.split())
    print("Общее количество слов: {}".format(word_count))
file.close()
