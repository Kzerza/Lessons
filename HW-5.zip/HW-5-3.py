''' Задание №3
'''

with open("HW-5-3.txt", "r") as file:
    salary = []
    result = []
    name_list = file.readlines()
    for index in name_list:
        index = index.split()
        if int(index[1]) < 20000:
            result.append(index[0])
        salary.append(index[1])
print("Оклад меньше 20000: {0}, средний оклад {1}".format(
    result, (sum(map(int, salary)) / len(salary))))
