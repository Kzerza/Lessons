''' Задание №4
'''

translate = {"One": "Один", "Two": "Два", "Three": "Три", "Four": "Четыре"}
write_to_file = []

with open("HW-5-4.txt", "r") as file:
    for index in file:
        index = index.split(' ', 1)
        write_to_file.append(translate[index[0]] + ' ' + index[1])
    print(write_to_file)
file.close()

with open("HW-5-4-new.txt", "w") as file_write:
    file_write.writelines(write_to_file)
file_write.close()
