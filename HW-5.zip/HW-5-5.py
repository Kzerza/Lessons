''' Задание №5
'''


def writenumbers():
    with open("HW-5-5.txt", "w") as file:
        count = input("Введите цифры: ")
        file.write(count)
        file.close()
    try:
        with open("HW-5-5.txt", "r") as file_read:
            result = 0
            for index in file_read:
                result += sum(map(int, index.split()))
            print("Сумма чисел: {}".format(result))
        file_read.close()
    except FileNotFoundError:
        print("Файл не существует")


writenumbers()
