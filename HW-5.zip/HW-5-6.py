''' Задание №6
'''

subj = {}
with open('HW-5-6.txt', 'r') as file:
    for index in file:
        subject, lecture, practice, lab = index.split()
        lecture = ''.join(filter(str.isdigit, lecture))
        practice = ''.join(filter(str.isdigit, practice))
        lab = ''.join(filter(str.isdigit, lab))
        subject = ''.join(x for x in subject if x.isalnum())
        if lecture.isnumeric() is False:
            lecture = 0
        if practice.isnumeric() is False:
            practice = 0
        if lab.isnumeric() is False:
            lab = 0
        subj[subject] = int(lecture) + \
            int(practice) + int(lab)
    print("Общее количество часов по предмету - \n {}".format(subj))
file.close
