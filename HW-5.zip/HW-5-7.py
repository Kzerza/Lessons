''' Задание №7
'''

import json
profit = {}
pr = {}
prof = 0
prof_aver = 0
i = 0
with open("HW-5-7.txt", "r") as file:
    for index in file:
        name, firm, earning, damage = index.split()
        profit[name] = int(earning) - int(damage)
        if profit.setdefault(name) >= 0:
            prof = prof + profit.setdefault(name)
            i += 1
    if i != 0:
        prof_aver = prof / i
        print("Средняя прибыль: {:.2f}".format(prof_aver))
    else:
        print("Средняя прибыль: отсутсвует")
    pr = {"Средняя прибыль": round(prof_aver)}
    profit.update(pr)
    print("Прибыль каждой компании - {}".format(profit))
file.close()

with open("HW-5-7.json", 'w') as write_file_js:
    json.dump(profit, write_file_js)
    js_str = json.dumps(profit)
    print("Содержимое json:\n{}".format(js_str))
write_file_js.close()
